﻿---
title: '部署参考: Exchange 2013 Help'
TOCTitle: 部署参考
ms:assetid: 1999c070-1441-4605-b36b-118a5d78defe
ms:mtpsurl: https://technet.microsoft.com/zh-cn/library/JJ150490(v=EXCHG.150)
ms:contentKeyID: 50490112
ms.date: 01/11/2018
mtps_version: v=EXCHG.150
ms.translationtype: HT
---

# 部署参考

 

_**适用于：** Exchange Server 2013_

_**上一次修改主题：** 2013-08-02_

[Exchange 2013：版次和版本](exchange-2013-editions-and-versions-exchange-2013-help.md)

[Exchange Server 更新：内部版本号和发行日期](https://technet.microsoft.com/zh-cn/library/hh135098\(v=exchg.150\))

[Exchange 服务器可支持性矩阵](exchange-server-supportability-matrix-exchange-2013-help.md)

[Exchange 2013 部署权限参考](exchange-2013-deployment-permissions-reference-exchange-2013-help.md)

[部署安全性核对清单](deployment-security-checklist-exchange-2013-help.md)

[Exchange 2013 大小调整和容量规划](exchange-2013-sizing-and-capacity-planning-exchange-2013-help.md)

[Exchange 2013 存储配置选项](exchange-2013-storage-configuration-options-exchange-2013-help.md)

[Exchange 2013 中的 IPv6 支持](ipv6-support-in-exchange-2013-exchange-2013-help.md)

[Exchange 2013 语言支持](exchange-2013-language-support-exchange-2013-help.md)

[Exchange 2013 准备情况检查](exchange-2013-readiness-checks-exchange-2013-help.md)

