﻿---
title: '允许用户进行调用过程: Exchange Online Help'
TOCTitle: 允许用户进行调用过程
ms:assetid: 6997797d-4b79-4f6d-a89a-f36eea4e5ca4
ms:mtpsurl: https://technet.microsoft.com/zh-cn/library/JJ938011(v=EXCHG.150)
ms:contentKeyID: 52061376
ms.date: 05/23/2018
mtps_version: v=EXCHG.150
ms.translationtype: MT
---

# 允许用户进行调用过程

 

_**适用于：** Exchange Online, Exchange Server 2013, Exchange Server 2016_

_**上一次修改主题：** 2013-05-03_

[启用 UM IP 网关的传出呼叫](enable-outgoing-calls-on-um-ip-gateways-exchange-2013-help.md)

[禁用 UM IP 网关的传出呼叫](disable-outgoing-calls-on-um-ip-gateways-exchange-2013-help.md)

[配置拨号代码](configure-dial-codes-exchange-2013-help.md)

[创建用户的拨号规则](create-dialing-rules-for-users-exchange-2013-help.md)

[使用拨号规则授权通话](authorize-calls-using-dialing-rules-exchange-2013-help.md)

[用于自动助理调用方授权调用](authorize-calls-for-auto-attendant-callers-exchange-2013-help.md)

[拨号计划中授权用户的呼叫](authorize-calls-for-users-in-a-dial-plan-exchange-2013-help.md)

[授权一组用户的呼叫](authorize-calls-for-a-group-of-users-exchange-2013-help.md)

