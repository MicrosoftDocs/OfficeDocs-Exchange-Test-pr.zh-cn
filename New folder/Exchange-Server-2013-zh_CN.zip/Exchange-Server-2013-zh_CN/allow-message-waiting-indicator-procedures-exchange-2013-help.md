﻿---
title: '允许消息等待指示符过程: Exchange Online Help'
TOCTitle: 允许消息等待指示符过程
ms:assetid: 608082bc-015e-45ef-8ebc-f77465080381
ms:mtpsurl: https://technet.microsoft.com/zh-cn/library/Dn135233(v=EXCHG.150)
ms:contentKeyID: 54652286
ms.date: 05/23/2018
mtps_version: v=EXCHG.150
ms.translationtype: MT
---

# 允许消息等待指示符过程

 

_**适用于：** Exchange Server 2013, Exchange Server 2016_

_**上一次修改主题：** 2013-05-03_

[在 UM IP 网关允许消息等待指示符 (MWI)](allow-message-waiting-indicator-mwi-on-a-um-ip-gateway-exchange-2013-help.md)

[消息等待指示符 (MWI) 如果不在 UM IP 网关](prevent-message-waiting-indicator-mwi-on-a-um-ip-gateway-exchange-2013-help.md)

[为用户启用消息等待指示符 (MWI)](enable-message-waiting-indicator-mwi-for-users-exchange-2013-help.md)

[为用户禁用消息等待指示符 (MWI)](disable-message-waiting-indicator-mwi-for-users-exchange-2013-help.md)

[启用用户的未接的来电通知](enable-missed-call-notifications-for-a-user-exchange-2013-help.md)

[禁用用户的未接的来电通知](disable-missed-call-notifications-for-a-user-exchange-2013-help.md)

