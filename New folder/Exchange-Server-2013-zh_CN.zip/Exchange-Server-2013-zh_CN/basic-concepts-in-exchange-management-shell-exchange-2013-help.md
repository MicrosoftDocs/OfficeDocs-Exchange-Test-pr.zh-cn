﻿---
title: 'Exchange 命令行管理程序中的基本概念: Exchange 2013 Help'
TOCTitle: Exchange 命令行管理程序中的基本概念
ms:assetid: 87289884-7526-4f12-bf36-b252f4eff97e
ms:mtpsurl: https://technet.microsoft.com/zh-cn/library/Dn659284(v=EXCHG.150)
ms:contentKeyID: 61602013
ms.date: 05/21/2018
mtps_version: v=EXCHG.150
ms.translationtype: MT
---

# Exchange 命令行管理程序中的基本概念

 

_**上一次修改主题：** 2014-04-04_

## 获取帮助

[获取帮助](https://technet.microsoft.com/zh-cn/library/aa997174\(v=exchg.150\))

## Cmdlet 和参数

[Cmdlet](cmdlets-exchange-2013-help.md)

[参数](https://technet.microsoft.com/zh-cn/library/bb124388\(v=exchg.150\))

[结构化数据](https://technet.microsoft.com/zh-cn/library/aa996386\(v=exchg.150\))

[语法](https://technet.microsoft.com/zh-cn/library/bb123552\(v=exchg.150\))

## 运行命令

[别名](https://technet.microsoft.com/zh-cn/library/bb123977\(v=exchg.150\))

[数组](https://technet.microsoft.com/zh-cn/library/aa998267\(v=exchg.150\))

[比较运算符](https://technet.microsoft.com/zh-cn/library/bb125229\(v=exchg.150\))

[身份](identity-exchange-2013-help.md)

[在 Exchange 命令行管理程序中导入和导出文件](import-and-export-files-in-the-exchange-management-shell-exchange-2013-help.md)

[修改多值属性](modifying-multivalued-properties-exchange-2013-help.md)

[管道传输](https://technet.microsoft.com/zh-cn/library/aa998260\(v=exchg.150\))

[WhatIf、Confirm 和 ValidateOnly 开关](whatif-confirm-and-validateonly-switches-exchange-2013-help.md)

[使用命令输出](working-with-command-output-exchange-2013-help.md)

## 运行脚本

[使用 Exchange 命令行管理程序编写脚本](https://technet.microsoft.com/zh-cn/library/bb123798\(v=exchg.150\))

[脚本安全性](https://technet.microsoft.com/zh-cn/library/bb125017\(v=exchg.150\))

[命令行管理程序变量](https://technet.microsoft.com/zh-cn/library/bb124036\(v=exchg.150\))

[用户定义的变量](https://technet.microsoft.com/zh-cn/library/bb123690\(v=exchg.150\))

