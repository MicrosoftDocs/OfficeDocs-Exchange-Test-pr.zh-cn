﻿---
title: 'Exchange 2013 大小调整和容量规划: Exchange 2013 Help'
TOCTitle: Exchange 2013 大小调整和容量规划
ms:assetid: d9852860-1a4c-4162-83f1-7131432be7d6
ms:mtpsurl: https://technet.microsoft.com/zh-cn/library/Dn178505(v=EXCHG.150)
ms:contentKeyID: 54652300
ms.date: 01/11/2018
mtps_version: v=EXCHG.150
ms.translationtype: HT
---

# Exchange 2013 大小调整和容量规划

 

_**适用于：** Exchange Server 2013_

_**上一次修改主题：** 2016-12-09_

Exchange Server 2013 的大小调整和容量规划是 Exchange 2013 部署的重要部分。配置系统以实现最佳性能是一个反复的过程。花费时间了解所有影响系统的变量，包括用户配置文件、体系结构和硬件。了解这些方面之后，可以为您的系统设定基准度量值并进行调整以提高系统性能。有关您的 Exchange 组织的大小调整和容量规划的详细信息和指导，请参阅 Exchange 团队博客文章[询问 Perf Guy：调整 Exchange 2013 部署大小](https://go.microsoft.com/fwlink/p/?linkid=301990)和 [Exchange Server 2013 性能建议](exchange-server-2013-performance-recommendations-exchange-2013-help.md)。

