﻿---
title: '电子邮件地址策略程序: Exchange 2013 Help'
TOCTitle: 电子邮件地址策略程序
ms:assetid: 7b49b51d-265e-4857-a283-4368e858f8a5
ms:mtpsurl: https://technet.microsoft.com/zh-cn/library/Aa998940(v=EXCHG.150)
ms:contentKeyID: 50491040
ms.date: 01/11/2018
mtps_version: v=EXCHG.150
ms.translationtype: HT
---

# 电子邮件地址策略程序

 

_**适用于：** Exchange Server 2013_

_**上一次修改主题：** 2012-10-13_

[创建电子邮件地址策略](create-an-email-address-policy-exchange-2013-help.md)

[通过使用收件人筛选器创建电子邮件地址策略](create-an-email-address-policy-by-using-recipient-filters-exchange-2013-help.md)

[编辑电子邮件地址策略](edit-an-email-address-policy-exchange-2013-help.md)

[删除电子邮件地址策略](remove-an-email-address-policy-exchange-2013-help.md)

