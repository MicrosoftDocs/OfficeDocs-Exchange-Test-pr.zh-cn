﻿---
title: '部署证书的 UM 过程: Exchange 2013 Help'
TOCTitle: 部署证书的 UM 过程
ms:assetid: 21631c68-86ad-4f00-a1eb-dcc2758f6bf0
ms:mtpsurl: https://technet.microsoft.com/zh-cn/library/Dn205139(v=EXCHG.150)
ms:contentKeyID: 54652273
ms.date: 05/21/2018
mtps_version: v=EXCHG.150
ms.translationtype: MT
---

# 部署证书的 UM 过程

 

_**适用于：** Exchange Server 2013, Exchange Server 2016_

_**上一次修改主题：** 2013-04-19_

[创建 UM 证书](create-certificates-for-um-exchange-2013-help.md)

[导入或导出证书为 UM](import-or-export-certificates-for-um-exchange-2013-help.md)

[将证书分配给该 UM 和 UM 呼叫路由器服务](assign-a-certificate-to-the-um-and-um-call-router-services-exchange-2013-help.md)

