﻿---
title: 'Exchange 2007 服务器必须升级至 Service Pack 3、更新汇总 10: Exchange 2013 Help'
TOCTitle: Exchange 2007 服务器必须升级至 Service Pack 3、更新汇总 10
ms:assetid: b8028a00-c451-412e-86f2-1669f6eee8fc
ms:mtpsurl: https://technet.microsoft.com/zh-cn/library/ms.exch.setupreadiness.e15e12coexistenceminversionrequirement(v=EXCHG.150)
ms:contentKeyID: 50491484
ms.date: 05/21/2018
mtps_version: v=EXCHG.150
ms.translationtype: MT
---

# Exchange 2007 服务器必须升级至 Service Pack 3、更新汇总 10

 

_**适用于：** Exchange Server_

_**上一次修改主题：** 2016-12-09_

Microsoft Exchange Server 2013安装程序无法继续，因为它检测到一个或多个Exchange Server 2007服务器还没有已升级到Exchange Server 2007 Service Pack 3 (SP3) 10 (RU10) 的汇总。您可以安装Exchange 2013之前，您的组织中的所有Exchange 2007服务器必须都升级到 SP3 RU10 的Exchange 2007 。此要求完全包括了Exchange 2007边缘传输服务器。有关详细信息，请参阅[从 Exchange 2007 升级到 Exchange 2013](upgrade-from-exchange-2007-to-exchange-2013-exchange-2013-help.md)。

> [!important]
> 升级到Exchange 2007 SP3 RU10 Exchange 2007边缘传输服务器后，必须重新创建边缘订阅Exchange组织和每个边缘传输服务器，以更新其在 Active Directory 的服务器版本之间。有关重新创建边缘订阅中Exchange 2007的详细信息，请参阅<a href="https://go.microsoft.com/fwlink/?linkid=282699">订阅边缘传输服务器到 Exchange 组织</a>。

