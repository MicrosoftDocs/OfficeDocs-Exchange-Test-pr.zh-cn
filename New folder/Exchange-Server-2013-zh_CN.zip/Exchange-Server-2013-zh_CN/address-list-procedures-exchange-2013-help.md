﻿---
title: '地址列表程序: Exchange 2013 Help'
TOCTitle: 地址列表程序
ms:assetid: 44c87349-964b-4700-9ce9-87bd4cb2249e
ms:mtpsurl: https://technet.microsoft.com/zh-cn/library/Aa997686(v=EXCHG.150)
ms:contentKeyID: 50490448
ms.date: 01/11/2018
mtps_version: v=EXCHG.150
ms.translationtype: HT
---

# 地址列表程序

 

_**适用于：** Exchange Server 2013_

_**上一次修改主题：** 2012-10-12_

[创建地址列表](create-an-address-list-exchange-2013-help.md)

[更新地址列表](update-an-address-list-exchange-2013-help.md)

[使用收件人筛选器创建地址列表](create-an-address-list-by-using-recipient-filters-exchange-2013-help.md)

[移动地址列表](move-an-address-list-exchange-2013-help.md)

[删除地址列表](remove-an-address-list-exchange-2013-help.md)

[创建全局地址列表](create-a-global-address-list-exchange-2013-help.md)

[配置全局地址列表属性](configure-global-address-list-properties-exchange-2013-help.md)

[删除全局地址列表](remove-a-global-address-list-exchange-2013-help.md)

[更新全局地址列表](update-a-global-address-list-exchange-2013-help.md)

