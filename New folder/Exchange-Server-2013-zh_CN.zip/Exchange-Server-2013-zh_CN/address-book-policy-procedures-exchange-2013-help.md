﻿---
title: '通讯簿策略程序: Exchange 2013 Help'
TOCTitle: 通讯簿策略程序
ms:assetid: 1204db89-ee4b-459a-8c14-e8d60dd6c4a4
ms:mtpsurl: https://technet.microsoft.com/zh-cn/library/Hh529916(v=EXCHG.150)
ms:contentKeyID: 50489938
ms.date: 01/11/2018
mtps_version: v=EXCHG.150
ms.translationtype: HT
---

# 通讯簿策略程序

 

_**适用于：** Exchange Server 2013_

_**上一次修改主题：** 2012-10-11_

[创建通讯簿策略](create-an-address-book-policy-exchange-2013-help.md)

[将通讯簿策略分配给邮件用户](assign-an-address-book-policy-to-mail-users-exchange-2013-help.md)

[更改通讯簿策略的设置](change-the-settings-of-an-address-book-policy-exchange-2013-help.md)

[删除通讯簿策略](remove-an-address-book-policy-exchange-2013-help.md)

